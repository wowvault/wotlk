local AceLocale = LibStub:GetLibrary("AceLocale-3.0-ElvUI")
local L = AceLocale:NewLocale("ElvUI", "enUS", true)

if not L then return end

L["Button Glow"] = true
L["Overlay Frame"] = true
L["Overlay Frame Scale"] = true
L["Disable Sound"] = true
L["Disable playing sound on overlay proc."] = true