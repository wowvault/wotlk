local E, L, V, P, G = unpack(ElvUI)

V.addOnSkins = {
	Blizzard_WorldStateFrame = true,
}